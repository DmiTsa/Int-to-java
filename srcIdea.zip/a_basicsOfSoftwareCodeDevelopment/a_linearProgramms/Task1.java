package a_basicsOfSoftwareCodeDevelopment.a_linearProgramms;

public class Task1 {
    // Найдите значение функции z=((a-3)*b/2)+c
    public static void main(String[] args) {
        int a = 5, b = 4, c = 3;
        int z = (a - 3) * b / 2 + c;
        System.out.print(z);
    }
}
