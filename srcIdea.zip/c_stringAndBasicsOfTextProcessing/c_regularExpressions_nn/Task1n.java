package c_stringAndBasicsOfTextProcessing.c_regularExpressions_nn;

import java.util.regex.Pattern;

public class Task1n {
    //Cоздать приложение, разбирающее текст (текст хранится в строке) и позволяющее выполнять с текстом три различных
    //операции: отсортировать абзацы по количеству предложений; в каждом предложении отсортировать слова по длине;
    //отсортировать лексемы в предложении по убыванию количества вхождений заданного символа, а в случае равенства – по
    //алфавиту.
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile(" ");

    }
}
