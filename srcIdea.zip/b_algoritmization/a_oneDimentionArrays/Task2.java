package b_algoritmization.a_oneDimentionArrays;

import java.util.Arrays;

public class Task2 {
    /*
Дана последовательность действительных чисел а1, а2, ... ,аn.
Заменить все ее члены, большие данного Z, этим
числом. Подсчитать количество замен.
 */
    public static void main(String[] args) {
        int[] arr = {5, 7, 8, 12, 1};
        int z = 9;
        System.out.println("Начальный массив");
        System.out.println(Arrays.toString(arr));
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > z) {
                arr[i] = z;
                count++;
            }
        }
        System.out.println("Новый массив");
        System.out.println(Arrays.toString(arr));
        System.out.println("Замен " + count);

    }
}
